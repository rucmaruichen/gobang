#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QPainter>
#include <QMouseEvent>
#include <QMessageBox>
#include <QMediaPlayer>
#include "pieces.h"
#include <QDebug>
#define CHESS_ROWS		14
#define CHESS_COLUMES	14
#define RECT_WIDTH		65
#define RECT_HEIGHT		64
#define INF    10000
#define SIZE 15
class GameWidget : public QWidget
{
    Q_OBJECT
public:
    GameWidget(QWidget *parent = nullptr);
    ~GameWidget();
    void setDiff(int diff);      //设置难度
    void evaluate_naive();
    void evaluate_naive_easy();
    void evaluate_naive2();
    int get_diff();
    void Minimax_Decision(int _bIsBlackTurn);
    int Max_Value(int player,int a,int b,int depth);
    int Min_Value(int player,int a,int b,int depth);
    int Check();
private:
    void DrawPieces();
    void DrawChessAtPoint(QPainter& painter,QPoint& pt);
    void DrawItemWithMouse();        //鼠标跟随

    int CountNearItem(Pieces item,QPoint ptDirection);
protected:
    void mousePressEvent(QMouseEvent * e);
    void paintEvent(QPaintEvent *);

private:
    int _diff = 0;
    QVector<Pieces> _pieces;
    bool _bIsBlackTurn;	//当前该黑棋下
    int board[15][15]={0};
    int score[15][15]={0};
signals:
};

#endif // GAMEWIDGET_H
