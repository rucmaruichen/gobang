#include "Include/gamewidget.h"
GameWidget::GameWidget(QWidget *parent) : QWidget(parent)
{
    this->setMouseTracking(true);
    this->setFixedSize(1000, 1000);
    _bIsBlackTurn = false;
    memset(score,0,sizeof(score));
    QMediaPlayer *player=new QMediaPlayer;
    player->setMedia(QUrl("qrc:/music/BGM.mp3"));
    player->setVolume(20);
    player->play();
}
GameWidget::~GameWidget()
{
}
int GameWidget::get_diff()
{
    return _diff;
}
void GameWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/picture/table.jpg");
    painter.drawPixmap(0, 0, this->width(), this->height(), pix);
    DrawPieces();			//画棋子
    DrawItemWithMouse();	//画鼠标（当前方的棋子形状）

    update();
}

void GameWidget::setDiff(int diff)
{
    _diff = diff;
}

void GameWidget::DrawPieces()
{
    QPainter painter(this);
    painter.setPen(QPen(QColor(Qt::transparent)));

    for (int i = 0; i<_pieces.size(); i++)
    {
        Pieces pieces = _pieces[i];
        if (pieces._bBlack)
        {
            painter.setBrush(Qt::black);
        }
        else
        {
            painter.setBrush(Qt::white);
        }
        DrawChessAtPoint(painter,pieces._pt);
    }
}

void GameWidget::DrawChessAtPoint(QPainter& painter,QPoint& pt)
{
    QPoint ptCenter(13+(pt.x()+0.5)*RECT_WIDTH,16+(pt.y()+0.5)*RECT_HEIGHT);
    painter.drawEllipse(ptCenter,RECT_WIDTH / 2,RECT_HEIGHT / 2);
}

void GameWidget::DrawItemWithMouse()
{
    QPainter painter(this);
    painter.setPen(QPen(QColor(Qt::transparent)));

    if (_bIsBlackTurn)
    {
        painter.setBrush(Qt::black);
    }
    else
    {
        painter.setBrush(Qt::white);
    }

    painter.drawEllipse(mapFromGlobal(QCursor::pos()),RECT_WIDTH / 2,RECT_HEIGHT / 2);

}


void GameWidget::mousePressEvent(QMouseEvent * e)
{
    if(!_bIsBlackTurn)                    //玩家走白棋
    {
    //求鼠标点击处的棋子点pt
    QPoint pt;
    pt.setX( (e->pos().x() ) / RECT_WIDTH);
    pt.setY( (e->pos().y() ) / RECT_HEIGHT);

    //如果已存在棋子，就什么也不做
    for (int i = 0; i<_pieces.size(); i++)
    {
        Pieces item = _pieces[i];
        if (item._pt == pt)
        {
            //已有棋子
            return;
        }
    }
    //不存在棋子，就下一个
    Pieces piece(pt,_bIsBlackTurn);
    board[piece._pt.x()][piece._pt.y()]=1;
    _pieces.append(piece);

    //统计4个方向是否五子连
    int nLeft =			CountNearItem(piece,QPoint(-1,0));
    int nLeftUp =		CountNearItem(piece,QPoint(-1,-1));
    int nUp =			CountNearItem(piece,QPoint(0,-1));
    int nRightUp =		CountNearItem(piece,QPoint(1,-1));
    int nRight =		CountNearItem(piece,QPoint(1,0));
    int nRightDown =	CountNearItem(piece,QPoint(1,1));
    int nDown =			CountNearItem(piece,QPoint(0,1));
    int nLeftDown =		CountNearItem(piece,QPoint(-1,1));
    if ( (nLeft + nRight) >= 4 ||
         (nLeftUp + nRightDown) >= 4 ||
         (nUp + nDown) >= 4 ||
         (nRightUp + nLeftDown) >= 4 )
    {
        QString str = _bIsBlackTurn?"YOU LOSE":"YOU WIN";
        QMessageBox::information(NULL,  "GAME OVER",str, QMessageBox::Yes , QMessageBox::Yes);
        _pieces.clear();
        memset(board,0,sizeof (board));
        return;
    }
    }
    else //电脑走黑棋
    {
        if(get_diff()==0)           //低难度
        evaluate_naive_easy();
        if(get_diff()==2)
            Minimax_Decision(1);
        if(get_diff()==1)
            evaluate_naive();
        int max_score=0;
        int x0,y0,j,k;
        for(j=0;j<15;j++)
            for(k=0;k<15;k++)
                if(score[j][k]>max_score)
                {
                    max_score=score[j][k];
                    x0=j;
                    y0=k;
                }
        board[x0][y0]=2;
        QPoint pt(x0,y0);
        Pieces piece(pt,_bIsBlackTurn);
        _pieces.append(piece);
        //统计4个方向是否五子连
        int nLeft =			CountNearItem(piece,QPoint(-1,0));
        int nLeftUp =		CountNearItem(piece,QPoint(-1,-1));
        int nUp =			CountNearItem(piece,QPoint(0,-1));
        int nRightUp =		CountNearItem(piece,QPoint(1,-1));
        int nRight =		CountNearItem(piece,QPoint(1,0));
        int nRightDown =	CountNearItem(piece,QPoint(1,1));
        int nDown =			CountNearItem(piece,QPoint(0,1));
        int nLeftDown =		CountNearItem(piece,QPoint(-1,1));
        if ( (nLeft + nRight) >= 4 ||
             (nLeftUp + nRightDown) >= 4 ||
             (nUp + nDown) >= 4 ||
             (nRightUp + nLeftDown) >= 4 )
        {
            QString str = _bIsBlackTurn?"YOU LOSE":"YOU WIN";
            QMessageBox::information(NULL,  "GAME OVER",str, QMessageBox::Yes , QMessageBox::Yes);
            _pieces.clear();
            memset(board,0,sizeof (board));
            return;
        }
    }





    //该另一方下棋了
    _bIsBlackTurn = !_bIsBlackTurn;

}

int GameWidget::CountNearItem(Pieces piece,QPoint ptDirection)
{
    int nCount = 0;
    piece._pt += ptDirection;

    while (_pieces.contains(piece))           //contains条件:坐标和黑白都一样
    {
        nCount++;
        piece._pt += ptDirection;
    }
    return nCount;
}
void GameWidget::Minimax_Decision(int _bIsBlackTurn){ //min-max搜索
    int max = -INF;
    int i0=-1,j0=-1; //最大效用对于的棋盘位置
    for(int i = 0; i < SIZE; i++){
        for(int j = 0; j < SIZE; j++){
            if(board[i][j] == 0){
                board[i][j] =2;
                int temp = Min_Value(_bIsBlackTurn,max,INF,0);
                if(max < temp){
                    max = temp;
                    i0=i;
                    j0=j;
                }
                board[i][j] = 0;//计算完成之后，恢复棋局状态
            }
        }
    }
    score[i0][j0]=max;
}
int GameWidget::Max_Value(int _bIsBlackTurn,int a,int b,int d){
    d++;
    int re = Check();//判断棋局
    int i,j,k,max_score=-INF;
    //如果棋局完结，给出当前棋局状态的价值
    if(re == 2) return 50000;
    if(re == 1) return -100000;
    if(d>1)
    {
        evaluate_naive();
        for(j=0;j<15;j++)
            for(k=0;k<15;k++)
                if(score[j][k]>max_score)
                    max_score=score[j][k];
        memset(score,0,sizeof(score));
        return max_score;
    }
    //to-do 如果棋局尚未完结，扩展当前棋局，递归计算价值
    for(i=0;i<15;i++)
        for(j=0;j<15;j++)
        if(board[i][j]==0)
        {
                if(_bIsBlackTurn)
                board[i][j] =2;//在当前棋局状态下进行扩展（预测）
                else board[i][j]=1;
            int temp = Min_Value(-_bIsBlackTurn,a,b,d);
            if(a<temp)
                a=temp;
            if(b<=a)
            {
                board[i][j]=0;
                break;
            }
            board[i][j]=0;
        }
    return a;
}
int GameWidget::Min_Value(int _bIsBlackTurn,int a,int b,int d){
    d++;
    int re = Check(); //判断棋局
    int i,j,k,min_score=INF;
    //如果棋局完结，给出当前棋局状态的价值
    if(re == 2) return 50000; //计算机赢，价值为1
    if(re == 1) return -100000; //人类棋手赢，价值为-1
    //to-do 如果棋局尚未完结，扩展当前棋局，递归计算价值
    if(d>1)
    {
        evaluate_naive2();
        for(j=0;j<15;j++)
            for(k=0;k<15;k++)
                if(-score[j][k]<min_score)
                    min_score=-score[j][k];
        memset(score,0,sizeof(score));
        return min_score;
    }
    for(i=0;i<15;i++)
        for(j=0;j<15;j++)
        if(board[i][j]==0)
        {
            if(_bIsBlackTurn)
            board[i][j] =2;//在当前棋局状态下进行扩展（预测）
            else board[i][j]=1;
            int temp = Max_Value(-_bIsBlackTurn,a,b,d);
            if(b>temp)
                b=temp;
            if(b<=a)
            {
                board[i][j]=0;
                break;
            }
            board[i][j]=0;
        }
    return b;
}
int GameWidget::Check()
{
    int i,j;
    for(i=0;i<15;i++)
        for(j=0;j<15;j++)
        {
            if(board[i][j]!=0)
            {   int t=board[i][j];
                int nLeft=0;
                int nLeftUp=0;
                int nUp=0;
                int nRightUp=0;
                int nRight=0;
                int nRightDown=0;
                int nDown=0;
                int nLeftDown=0;
                int k;
                for(k=1;k<=4;k++)
                {
                    if(board[i-k][j]==t&&i-k>=0)
                        nUp++;
                    else  break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i][j-k]==t&&j-k>=0)
                        nLeft++;
                    else break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i-k][j-k]==t&&i-k>=0&&j-k>=0)
                        nLeftUp++;
                    else break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i+k][j]==t&&i+k<15)
                        nDown++;
                    else  break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i+k][j-k]==t&&j-k>=0&&i+k<15)
                        nLeftDown++;
                    else  break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i][j+k]==t&&j+k<15)
                        nRight++;
                    else  break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i-k][j+k]==t&&i-k>=0&&j+k<15)
                        nRightUp++;
                    else  break;
                }
                for(k=1;k<=4;k++)
                {
                    if(board[i+k][j+k]==t&&i+k<15&&j+k<15)
                        nRightDown++;
                    else  break;
                }
                if ( (nLeft + nRight) >= 4 ||
                     (nLeftUp + nRightDown) >= 4 ||
                     (nUp + nDown) >= 4 ||
                     (nRightUp + nLeftDown) >= 4 )
                {
                    return t;
                }
            }
        }
    return 0;     //没结束
}
void GameWidget::evaluate_naive()	//每个空子的评估函数。需要对人落子和电脑已落子进行评价。人落子电脑要堵，电脑自己落子要做成5子
{
    memset(score,0,sizeof(score));
    int number1,number2,empty;
    for(int x=0;x<15;++x)
        for(int y=0;y<15;++y)
            if(board[x][y]==0)//评估每个空子
                for(int i=-1;i<=1;++i)
                    for(int j=-1;j<=1;++j)
                        if(!(i==0&&j==0))//0,0不动不用算
                        {
                            number1=0,number2=0,empty=0;
                            //对人落子评分
                           for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number1==1)	score[x][y]+=1;	//人若下该空子，就两子了，那么不管死活都是+1
                            else if(number1==2)
                            {
                                if(empty==1)	score[x][y]+=5;	//三子，死，+5
                                else if(empty==2)	score[x][y]+=10;//三子，活，+10
                            }
                            else if(number1==3)
                            {
                                if(empty==1)	score[x][y]+=20;//四子，死，+20
                                else if(empty==2)	score[x][y]+=100;//四子，活，+100
                            }
                            else if(number1==4) score[x][y]+=1000;//五子，+1000
                            //对电脑落子评分（我自己下了这个空子，会怎样）
                            empty=0;
                            for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number2==0)	score[x][y]+=1;	//电脑若下了该空子，就一子了，那么不管死活都是+1
                            else if(number2==1)	score[x][y]+=2;	//两子，+2
                            else if(number2==2)
                            {
                                if(empty==1)	score[x][y]+=8;	//三子，死，+8
                                else if(empty==2)	score[x][y]+=30;//三子，活，+30
                            }
                            else if(number2==3)
                            {
                                if(empty==1)	score[x][y]+=50;//四子，死，+50
                                else if(empty==2)	score[x][y]+=200;//四子，活，+200
                            }
                            else if(number2==4) score[x][y]+=10000;	//五子，+10000
                        }
}
void GameWidget::evaluate_naive2()	//每个空子的评估函数。需要对人落子和电脑已落子进行评价。人落子电脑要堵，电脑自己落子要做成5子
{
    memset(score,0,sizeof(score));
    int number1,number2,empty;
    for(int x=0;x<15;++x)
        for(int y=0;y<15;++y)
            if(board[x][y]==0)//评估每个空子
                for(int i=-1;i<=1;++i)
                    for(int j=-1;j<=1;++j)
                        if(!(i==0&&j==0))//0,0不动不用算
                        {
                            number1=0,number2=0,empty=0;
                            //对人落子评分
                           for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number1==1)	score[x][y]+=1;	//人若下该空子，就两子了，那么不管死活都是+1
                            else if(number1==2)
                            {
                                if(empty==1)	score[x][y]+=5;	//三子，死，+5
                                else if(empty==2)	score[x][y]+=10;//三子，活，+10
                            }
                            else if(number1==3)
                            {
                                if(empty==1)	score[x][y]+=20;//四子，死，+20
                                else if(empty==2)	score[x][y]+=100;//四子，活，+100
                            }
                            else if(number1==4) score[x][y]+=1000;//五子，+1000
                            //对电脑落子评分（我自己下了这个空子，会怎样）
                            empty=0;
                            for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number2==0)	score[x][y]+=1;	//电脑若下了该空子，就一子了，那么不管死活都是+1
                            else if(number2==1)	score[x][y]+=2;	//两子，+2
                            else if(number2==2)
                            {
                                if(empty==1)	score[x][y]+=8;	//三子，死，+8
                                else if(empty==2)	score[x][y]+=30;//三子，活，+30
                            }
                            else if(number2==3)
                            {
                                if(empty==1)	score[x][y]+=50;//四子，死，+50
                                else if(empty==2)	score[x][y]+=200;//四子，活，+200
                            }
                            else if(number2==4) score[x][y]+=10000;	//五子，+10000
                        }
}
void GameWidget::evaluate_naive_easy()	//每个空子的评估函数。需要对人落子和电脑已落子进行评价。人落子电脑要堵，电脑自己落子要做成5子
{
    memset(score,0,sizeof(score));
    int number1,number2,empty;
    for(int x=0;x<15;++x)
        for(int y=0;y<15;++y)
            if(board[x][y]==0)//评估每个空子
                for(int i=-1;i<=1;++i)
                    for(int j=-1;j<=1;++j)
                        if(!(i==0&&j==0))//0,0不动不用算
                        {
                            number1=0,number2=0,empty=0;
                            //对人落子评分
                           for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==1)	++number1;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number1==1)	score[x][y]+=1*2;	//人若下该空子，就两子了，那么不管死活都是+1
                            else if(number1==2)
                            {
                                if(empty==1)	score[x][y]+=5*2;	//三子，死，+5
                                else if(empty==2)	score[x][y]+=10*2;//三子，活，+10
                            }
                            else if(number1==3)
                            {
                                if(empty==1)	score[x][y]+=20*2;//四子，死，+20
                                else if(empty==2)	score[x][y]+=100*2;//四子，活，+100
                            }
                            else if(number1==4) score[x][y]+=1000*2;//五子，+1000
                            //对电脑落子评分（我自己下了这个空子，会怎样）
                            empty=0;
                            for(int k=1;k<=5;++k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            for(int k=-1;k>=-5;--k)
                                if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==2)	++number2;
                                else if(x+i*k>=0&&x+i*k<15&&y+j*k>=0&&y+j*k<15&&board[x+i*k][y+j*k]==0)	{++empty;break;}
                                else	break;
                            if(number2==0)	score[x][y]+=1;	//电脑若下了该空子，就一子了，那么不管死活都是+1
                            else if(number2==1)	score[x][y]+=2;	//两子，+2
                            else if(number2==2)
                            {
                                if(empty==1)	score[x][y]+=8;	//三子，死，+8
                                else if(empty==2)	score[x][y]+=30;//三子，活，+30
                            }
                            else if(number2==3)
                            {
                                if(empty==1)	score[x][y]+=50;//四子，死，+50
                                else if(empty==2)	score[x][y]+=200;//四子，活，+200
                            }
                            else if(number2==4) score[x][y]+=10000;	//五子，+10000
                        }
}
